import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  employeeModel:Employee = new Employee(0,"",0,""); 

  employees:Array<Employee> = [];

  constructor() {}

  ngOnInit(): void {
  }

  addEmployee()
  {
    alert(this.employeeModel.id+" "+this.employeeModel.name+" "+this.employeeModel.salary+" "+this.employeeModel.department);
    this.employees.push(this.employeeModel);
    this.employeeModel = new Employee(0,"",0,"");
  }
}
