import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-sort-employee',
  templateUrl: './sort-employee.component.html',
  styleUrls: ['./sort-employee.component.css']
})
export class SortEmployeeComponent implements OnInit {

  employees:Array<Employee> = [];
  service:EmployeeService;

  constructor(service:EmployeeService) {
    this.service = service;
    this.employees = service.getAllEmployees();
  }

  sortById()
  {
    this.employees.sort(function(a,b){
      return a.id-b.id;
    })
  }

  sortByName()
  {
    this.employees.sort(function(a,b){
      let name1 = a.name.toLowerCase;
      let name2 = b.name.toLowerCase;
      if(name1 < name2) return -1;
      if(name1 > name2) return 1;
      return 0;
    })
  }

  ngOnInit(): void {
  }

}
