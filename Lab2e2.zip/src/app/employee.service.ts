import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  employees:Array<Employee> = [];

  constructor() {
    let emp1 = new Employee(1001,"Rahul",9000,"JAVA");
    this.employees.push(emp1);
    let emp2 = new Employee(1002,'Vikash',11000,'ORAAPS');
    this.employees.push(emp2);
    let emp3 = new Employee(1003,'Uma',12000,'JAVA');
    this.employees.push(emp3);
    let emp4 = new Employee(1004,'Sachin',11500,'ORAAPS');
    this.employees.push(emp4);
    let emp5 = new Employee(1005,'Amol',7000,'.NET');
    this.employees.push(emp5);
    let emp6 = new Employee(1006,'Vishal',17000,'BI');
    this.employees.push(emp6);
    let emp7 = new Employee(1007,'Rajita',21000,'BI');
    this.employees.push(emp7);
    let emp8 = new Employee(1008,'Neelima',81000,'TESTING');
    this.employees.push(emp8);
    let emp9 = new Employee(1009,'Daya',1000,'TESTING');
    this.employees.push(emp9);
  }

  getAllEmployees()
  {
    return this.employees;
  }
}
