import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  employees:Array<Employee> = [];
  updateemp:Employee = new Employee(0,'',0,'');

  constructor() { 
    let emp1 = new Employee(1001,"Rahul",9000,"Java");
    let emp2 = new Employee(1002,"Sachin",19000,"OraApps");
    let emp3 = new Employee(1003,"Vikash",29000,"BI");
    this.employees.push(emp1);
    this.employees.push(emp2);
    this.employees.push(emp3);
  }

  addEmployee(emp:Employee)
  {
    this.employees.push(emp);
  }

  getAllEmployees()
  {
    return this.employees;
  }

  updateEmployee(upemp:Employee)
  {
    this.updateemp = upemp;
  }
}
