import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {

  service:EmployeeService;
  @Input() updateemp:Employee;
  @Output() sendmsg = new EventEmitter<string>();

  constructor(service:EmployeeService) {
    this.service = service;
  }

  ngOnInit(): void {
  }

  update()
  {
    this.service.updateEmployee(this.updateemp);
    this.sendmsg.emit("DATA UPDATED");
  }

}
