export class Product {

    id:number;
    name:string;
    cost:number;
    online:string;
    category:string;
    availablestores:Array<string>;

    constructor(id:number,name:string,cost:number,online:string,category:string,availablestores:Array<string>)
    {
        this.id = id;
        this.name = name;
        this.cost = cost;
        this.online = online;
        this.category = category;
        this.availablestores = availablestores;
    }

}
