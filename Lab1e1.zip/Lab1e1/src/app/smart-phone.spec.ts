import { SmartPhone } from './smart-phone';

describe('SmartPhone', () => {
  it('should create an instance', () => {
    expect(new SmartPhone()).toBeTruthy();
  });
});
